﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class SulfaroCH61Lab
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.gbx611Numbers = New System.Windows.Forms.GroupBox()
        Me.lstNumbersEX611 = New System.Windows.Forms.ListBox()
        Me.btnDisplayEX611 = New System.Windows.Forms.Button()
        Me.gbx612Quotations = New System.Windows.Forms.GroupBox()
        Me.txtQuotationEX612 = New System.Windows.Forms.TextBox()
        Me.btnDisplayEX612 = New System.Windows.Forms.Button()
        Me.gbx613AverageNum = New System.Windows.Forms.GroupBox()
        Me.btnComputeEX613 = New System.Windows.Forms.Button()
        Me.gbxEX614Quotations2 = New System.Windows.Forms.GroupBox()
        Me.txtQuotationEX614 = New System.Windows.Forms.TextBox()
        Me.btnDisplayEX614 = New System.Windows.Forms.Button()
        Me.gbxEX615Compound = New System.Windows.Forms.GroupBox()
        Me.lblAmountEX615 = New System.Windows.Forms.Label()
        Me.txtAmountEX615 = New System.Windows.Forms.TextBox()
        Me.btnCalculateEX615 = New System.Windows.Forms.Button()
        Me.txtWhenEX615 = New System.Windows.Forms.TextBox()
        Me.gbx611Numbers.SuspendLayout()
        Me.gbx612Quotations.SuspendLayout()
        Me.gbx613AverageNum.SuspendLayout()
        Me.gbxEX614Quotations2.SuspendLayout()
        Me.gbxEX615Compound.SuspendLayout()
        Me.SuspendLayout()
        '
        'gbx611Numbers
        '
        Me.gbx611Numbers.Controls.Add(Me.lstNumbersEX611)
        Me.gbx611Numbers.Controls.Add(Me.btnDisplayEX611)
        Me.gbx611Numbers.Location = New System.Drawing.Point(16, 12)
        Me.gbx611Numbers.Name = "gbx611Numbers"
        Me.gbx611Numbers.Size = New System.Drawing.Size(276, 154)
        Me.gbx611Numbers.TabIndex = 0
        Me.gbx611Numbers.TabStop = False
        Me.gbx611Numbers.Text = "EX 6.1.1 - Numbers"
        '
        'lstNumbersEX611
        '
        Me.lstNumbersEX611.FormattingEnabled = True
        Me.lstNumbersEX611.Location = New System.Drawing.Point(6, 32)
        Me.lstNumbersEX611.Name = "lstNumbersEX611"
        Me.lstNumbersEX611.Size = New System.Drawing.Size(120, 95)
        Me.lstNumbersEX611.TabIndex = 1
        '
        'btnDisplayEX611
        '
        Me.btnDisplayEX611.Location = New System.Drawing.Point(155, 58)
        Me.btnDisplayEX611.Name = "btnDisplayEX611"
        Me.btnDisplayEX611.Size = New System.Drawing.Size(89, 45)
        Me.btnDisplayEX611.TabIndex = 0
        Me.btnDisplayEX611.Text = "Display"
        Me.btnDisplayEX611.UseVisualStyleBackColor = True
        '
        'gbx612Quotations
        '
        Me.gbx612Quotations.Controls.Add(Me.txtQuotationEX612)
        Me.gbx612Quotations.Controls.Add(Me.btnDisplayEX612)
        Me.gbx612Quotations.Location = New System.Drawing.Point(298, 12)
        Me.gbx612Quotations.Name = "gbx612Quotations"
        Me.gbx612Quotations.Size = New System.Drawing.Size(288, 103)
        Me.gbx612Quotations.TabIndex = 1
        Me.gbx612Quotations.TabStop = False
        Me.gbx612Quotations.Text = "EX 6.1.2 - Movie Quotations"
        '
        'txtQuotationEX612
        '
        Me.txtQuotationEX612.Location = New System.Drawing.Point(49, 58)
        Me.txtQuotationEX612.Name = "txtQuotationEX612"
        Me.txtQuotationEX612.Size = New System.Drawing.Size(186, 20)
        Me.txtQuotationEX612.TabIndex = 1
        '
        'btnDisplayEX612
        '
        Me.btnDisplayEX612.Location = New System.Drawing.Point(66, 19)
        Me.btnDisplayEX612.Name = "btnDisplayEX612"
        Me.btnDisplayEX612.Size = New System.Drawing.Size(154, 23)
        Me.btnDisplayEX612.TabIndex = 0
        Me.btnDisplayEX612.Text = "Display a Movie Quotation"
        Me.btnDisplayEX612.UseVisualStyleBackColor = True
        '
        'gbx613AverageNum
        '
        Me.gbx613AverageNum.Controls.Add(Me.btnComputeEX613)
        Me.gbx613AverageNum.Location = New System.Drawing.Point(16, 172)
        Me.gbx613AverageNum.Name = "gbx613AverageNum"
        Me.gbx613AverageNum.Size = New System.Drawing.Size(276, 99)
        Me.gbx613AverageNum.TabIndex = 1
        Me.gbx613AverageNum.TabStop = False
        Me.gbx613AverageNum.Text = "EX 6.1.3 - Average of Numbers"
        '
        'btnComputeEX613
        '
        Me.btnComputeEX613.Location = New System.Drawing.Point(76, 30)
        Me.btnComputeEX613.Name = "btnComputeEX613"
        Me.btnComputeEX613.Size = New System.Drawing.Size(115, 43)
        Me.btnComputeEX613.TabIndex = 0
        Me.btnComputeEX613.Text = "Compute"
        Me.btnComputeEX613.UseVisualStyleBackColor = True
        '
        'gbxEX614Quotations2
        '
        Me.gbxEX614Quotations2.Controls.Add(Me.txtQuotationEX614)
        Me.gbxEX614Quotations2.Controls.Add(Me.btnDisplayEX614)
        Me.gbxEX614Quotations2.Location = New System.Drawing.Point(298, 121)
        Me.gbxEX614Quotations2.Name = "gbxEX614Quotations2"
        Me.gbxEX614Quotations2.Size = New System.Drawing.Size(288, 99)
        Me.gbxEX614Quotations2.TabIndex = 1
        Me.gbxEX614Quotations2.TabStop = False
        Me.gbxEX614Quotations2.Text = "EX 6.1.4 - Movie Quotations 2"
        '
        'txtQuotationEX614
        '
        Me.txtQuotationEX614.Location = New System.Drawing.Point(49, 59)
        Me.txtQuotationEX614.Name = "txtQuotationEX614"
        Me.txtQuotationEX614.Size = New System.Drawing.Size(186, 20)
        Me.txtQuotationEX614.TabIndex = 2
        '
        'btnDisplayEX614
        '
        Me.btnDisplayEX614.Location = New System.Drawing.Point(66, 30)
        Me.btnDisplayEX614.Name = "btnDisplayEX614"
        Me.btnDisplayEX614.Size = New System.Drawing.Size(154, 23)
        Me.btnDisplayEX614.TabIndex = 1
        Me.btnDisplayEX614.Text = "Display a Movie Quotation"
        Me.btnDisplayEX614.UseVisualStyleBackColor = True
        '
        'gbxEX615Compound
        '
        Me.gbxEX615Compound.Controls.Add(Me.txtWhenEX615)
        Me.gbxEX615Compound.Controls.Add(Me.btnCalculateEX615)
        Me.gbxEX615Compound.Controls.Add(Me.txtAmountEX615)
        Me.gbxEX615Compound.Controls.Add(Me.lblAmountEX615)
        Me.gbxEX615Compound.Location = New System.Drawing.Point(306, 226)
        Me.gbxEX615Compound.Name = "gbxEX615Compound"
        Me.gbxEX615Compound.Size = New System.Drawing.Size(280, 161)
        Me.gbxEX615Compound.TabIndex = 1
        Me.gbxEX615Compound.TabStop = False
        Me.gbxEX615Compound.Text = "EX 6.1.5 - Compound Interest"
        '
        'lblAmountEX615
        '
        Me.lblAmountEX615.AutoSize = True
        Me.lblAmountEX615.Location = New System.Drawing.Point(7, 49)
        Me.lblAmountEX615.Name = "lblAmountEX615"
        Me.lblAmountEX615.Size = New System.Drawing.Size(97, 13)
        Me.lblAmountEX615.TabIndex = 0
        Me.lblAmountEX615.Text = "Amount Deposited:"
        '
        'txtAmountEX615
        '
        Me.txtAmountEX615.Location = New System.Drawing.Point(111, 49)
        Me.txtAmountEX615.Name = "txtAmountEX615"
        Me.txtAmountEX615.Size = New System.Drawing.Size(163, 20)
        Me.txtAmountEX615.TabIndex = 1
        '
        'btnCalculateEX615
        '
        Me.btnCalculateEX615.Location = New System.Drawing.Point(10, 88)
        Me.btnCalculateEX615.Name = "btnCalculateEX615"
        Me.btnCalculateEX615.Size = New System.Drawing.Size(264, 23)
        Me.btnCalculateEX615.TabIndex = 2
        Me.btnCalculateEX615.Text = "Calculate Years to Become a Millionaire"
        Me.btnCalculateEX615.UseVisualStyleBackColor = True
        '
        'txtWhenEX615
        '
        Me.txtWhenEX615.Location = New System.Drawing.Point(10, 126)
        Me.txtWhenEX615.Name = "txtWhenEX615"
        Me.txtWhenEX615.ReadOnly = True
        Me.txtWhenEX615.Size = New System.Drawing.Size(264, 20)
        Me.txtWhenEX615.TabIndex = 3
        '
        'SulfaroCH61Lab
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(598, 400)
        Me.Controls.Add(Me.gbx612Quotations)
        Me.Controls.Add(Me.gbx613AverageNum)
        Me.Controls.Add(Me.gbxEX614Quotations2)
        Me.Controls.Add(Me.gbxEX615Compound)
        Me.Controls.Add(Me.gbx611Numbers)
        Me.Name = "SulfaroCH61Lab"
        Me.Text = "Sulfaro CH6.1 Lab"
        Me.gbx611Numbers.ResumeLayout(False)
        Me.gbx612Quotations.ResumeLayout(False)
        Me.gbx612Quotations.PerformLayout()
        Me.gbx613AverageNum.ResumeLayout(False)
        Me.gbxEX614Quotations2.ResumeLayout(False)
        Me.gbxEX614Quotations2.PerformLayout()
        Me.gbxEX615Compound.ResumeLayout(False)
        Me.gbxEX615Compound.PerformLayout()
        Me.ResumeLayout(False)

    End Sub

    Friend WithEvents gbx611Numbers As GroupBox
    Friend WithEvents lstNumbersEX611 As ListBox
    Friend WithEvents btnDisplayEX611 As Button
    Friend WithEvents gbx612Quotations As GroupBox
    Friend WithEvents gbx613AverageNum As GroupBox
    Friend WithEvents gbxEX614Quotations2 As GroupBox
    Friend WithEvents gbxEX615Compound As GroupBox
    Friend WithEvents txtQuotationEX612 As TextBox
    Friend WithEvents btnDisplayEX612 As Button
    Friend WithEvents btnComputeEX613 As Button
    Friend WithEvents txtQuotationEX614 As TextBox
    Friend WithEvents btnDisplayEX614 As Button
    Friend WithEvents lblAmountEX615 As Label
    Friend WithEvents txtWhenEX615 As TextBox
    Friend WithEvents btnCalculateEX615 As Button
    Friend WithEvents txtAmountEX615 As TextBox
End Class
