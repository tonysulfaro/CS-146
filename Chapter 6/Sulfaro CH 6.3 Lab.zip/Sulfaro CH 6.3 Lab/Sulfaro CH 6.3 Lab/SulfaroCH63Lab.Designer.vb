﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class SulfaroCH63Lab
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.gbx631 = New System.Windows.Forms.GroupBox()
        Me.btnDisplay631 = New System.Windows.Forms.Button()
        Me.lstLastTen631 = New System.Windows.Forms.ListBox()
        Me.lblStates631 = New System.Windows.Forms.Label()
        Me.lstStates631 = New System.Windows.Forms.ListBox()
        Me.gbx632 = New System.Windows.Forms.GroupBox()
        Me.mtbFirstTwoLetters632 = New System.Windows.Forms.MaskedTextBox()
        Me.lblFirstTwo632 = New System.Windows.Forms.Label()
        Me.btnSearch632 = New System.Windows.Forms.Button()
        Me.txtOutput632 = New System.Windows.Forms.TextBox()
        Me.lstStates632 = New System.Windows.Forms.ListBox()
        Me.lblStates632 = New System.Windows.Forms.Label()
        Me.gbx633 = New System.Windows.Forms.GroupBox()
        Me.txtHighest633 = New System.Windows.Forms.TextBox()
        Me.txtAverage633 = New System.Windows.Forms.TextBox()
        Me.txtGrade633 = New System.Windows.Forms.TextBox()
        Me.lstGrades633 = New System.Windows.Forms.ListBox()
        Me.lblGrade633 = New System.Windows.Forms.Label()
        Me.lblHighest633 = New System.Windows.Forms.Label()
        Me.lblAverage633 = New System.Windows.Forms.Label()
        Me.btnCalculate633 = New System.Windows.Forms.Button()
        Me.btnRecord633 = New System.Windows.Forms.Button()
        Me.gbx634 = New System.Windows.Forms.GroupBox()
        Me.txtOutput634 = New System.Windows.Forms.TextBox()
        Me.btnSearch634 = New System.Windows.Forms.Button()
        Me.mtbFirstTwoLetters634 = New System.Windows.Forms.MaskedTextBox()
        Me.lblFirstTwo634 = New System.Windows.Forms.Label()
        Me.lstStates634 = New System.Windows.Forms.ListBox()
        Me.gbx631.SuspendLayout()
        Me.gbx632.SuspendLayout()
        Me.gbx633.SuspendLayout()
        Me.gbx634.SuspendLayout()
        Me.SuspendLayout()
        '
        'gbx631
        '
        Me.gbx631.Controls.Add(Me.btnDisplay631)
        Me.gbx631.Controls.Add(Me.lstLastTen631)
        Me.gbx631.Controls.Add(Me.lblStates631)
        Me.gbx631.Controls.Add(Me.lstStates631)
        Me.gbx631.Location = New System.Drawing.Point(18, 18)
        Me.gbx631.Margin = New System.Windows.Forms.Padding(4, 5, 4, 5)
        Me.gbx631.Name = "gbx631"
        Me.gbx631.Padding = New System.Windows.Forms.Padding(4, 5, 4, 5)
        Me.gbx631.Size = New System.Drawing.Size(386, 323)
        Me.gbx631.TabIndex = 0
        Me.gbx631.TabStop = False
        Me.gbx631.Text = "EX 6.3.1 - U.S. States"
        '
        'btnDisplay631
        '
        Me.btnDisplay631.Location = New System.Drawing.Point(234, 42)
        Me.btnDisplay631.Margin = New System.Windows.Forms.Padding(4, 5, 4, 5)
        Me.btnDisplay631.Name = "btnDisplay631"
        Me.btnDisplay631.Size = New System.Drawing.Size(126, 57)
        Me.btnDisplay631.TabIndex = 3
        Me.btnDisplay631.Text = "Display Last Ten States"
        Me.btnDisplay631.UseVisualStyleBackColor = True
        '
        'lstLastTen631
        '
        Me.lstLastTen631.FormattingEnabled = True
        Me.lstLastTen631.ItemHeight = 20
        Me.lstLastTen631.Location = New System.Drawing.Point(234, 108)
        Me.lstLastTen631.Margin = New System.Windows.Forms.Padding(4, 5, 4, 5)
        Me.lstLastTen631.Name = "lstLastTen631"
        Me.lstLastTen631.Size = New System.Drawing.Size(124, 204)
        Me.lstLastTen631.TabIndex = 2
        '
        'lblStates631
        '
        Me.lblStates631.AutoSize = True
        Me.lblStates631.Location = New System.Drawing.Point(26, 57)
        Me.lblStates631.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.lblStates631.Name = "lblStates631"
        Me.lblStates631.Size = New System.Drawing.Size(60, 20)
        Me.lblStates631.TabIndex = 1
        Me.lblStates631.Text = "States:"
        '
        'lstStates631
        '
        Me.lstStates631.FormattingEnabled = True
        Me.lstStates631.ItemHeight = 20
        Me.lstStates631.Items.AddRange(New Object() {"Delaware", "Pennsylvania", "New Jersey", "Georgia", "Connecticut", "Massachusetts", "Maryland", "South Carolina", "New Hampshire", "Virginia", "New York", "North Carolina", "Rhode Island", "Vermont", "Kentucky", "Tennessee", "Ohio", "Louisiana", "Indiana", "Mississippi", "Illinois", "Alabama", "Maine", "Missouri", "Arkansas", "Michigan", "Florida", "Texas", "Iowa", "Wisconsin", "California", "Minnesota", "Oregon", "Kansas", "West Virginia", "Nevada", "Nebraska", "Colorado", "North Dakota", "South Dakota", "Montana", "Washington", "Idaho", "Wyoming", "Utah", "Oklahoma", "New Mexico", "Arizona", "Alaska", "Hawaii"})
        Me.lstStates631.Location = New System.Drawing.Point(26, 108)
        Me.lstStates631.Margin = New System.Windows.Forms.Padding(4, 5, 4, 5)
        Me.lstStates631.Name = "lstStates631"
        Me.lstStates631.Size = New System.Drawing.Size(124, 204)
        Me.lstStates631.TabIndex = 0
        '
        'gbx632
        '
        Me.gbx632.Controls.Add(Me.mtbFirstTwoLetters632)
        Me.gbx632.Controls.Add(Me.lblFirstTwo632)
        Me.gbx632.Controls.Add(Me.btnSearch632)
        Me.gbx632.Controls.Add(Me.txtOutput632)
        Me.gbx632.Controls.Add(Me.lstStates632)
        Me.gbx632.Controls.Add(Me.lblStates632)
        Me.gbx632.Location = New System.Drawing.Point(412, 18)
        Me.gbx632.Margin = New System.Windows.Forms.Padding(4, 5, 4, 5)
        Me.gbx632.Name = "gbx632"
        Me.gbx632.Padding = New System.Windows.Forms.Padding(4, 5, 4, 5)
        Me.gbx632.Size = New System.Drawing.Size(381, 323)
        Me.gbx632.TabIndex = 1
        Me.gbx632.TabStop = False
        Me.gbx632.Text = "EX 6.3.2 - U.S. States"
        '
        'mtbFirstTwoLetters632
        '
        Me.mtbFirstTwoLetters632.Location = New System.Drawing.Point(309, 68)
        Me.mtbFirstTwoLetters632.Margin = New System.Windows.Forms.Padding(4, 5, 4, 5)
        Me.mtbFirstTwoLetters632.Mask = "LL"
        Me.mtbFirstTwoLetters632.Name = "mtbFirstTwoLetters632"
        Me.mtbFirstTwoLetters632.Size = New System.Drawing.Size(61, 26)
        Me.mtbFirstTwoLetters632.TabIndex = 7
        '
        'lblFirstTwo632
        '
        Me.lblFirstTwo632.Location = New System.Drawing.Point(189, 60)
        Me.lblFirstTwo632.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.lblFirstTwo632.Name = "lblFirstTwo632"
        Me.lblFirstTwo632.Size = New System.Drawing.Size(114, 74)
        Me.lblFirstTwo632.TabIndex = 6
        Me.lblFirstTwo632.Text = "First two letters of state:"
        '
        'btnSearch632
        '
        Me.btnSearch632.Location = New System.Drawing.Point(208, 155)
        Me.btnSearch632.Margin = New System.Windows.Forms.Padding(4, 5, 4, 5)
        Me.btnSearch632.Name = "btnSearch632"
        Me.btnSearch632.Size = New System.Drawing.Size(112, 54)
        Me.btnSearch632.TabIndex = 5
        Me.btnSearch632.Text = "Search for State"
        Me.btnSearch632.UseVisualStyleBackColor = True
        '
        'txtOutput632
        '
        Me.txtOutput632.Location = New System.Drawing.Point(189, 249)
        Me.txtOutput632.Margin = New System.Windows.Forms.Padding(4, 5, 4, 5)
        Me.txtOutput632.Name = "txtOutput632"
        Me.txtOutput632.ReadOnly = True
        Me.txtOutput632.Size = New System.Drawing.Size(169, 26)
        Me.txtOutput632.TabIndex = 4
        '
        'lstStates632
        '
        Me.lstStates632.FormattingEnabled = True
        Me.lstStates632.ItemHeight = 20
        Me.lstStates632.Items.AddRange(New Object() {"Delaware", "Pennsylvania", "New Jersey", "Georgia", "Connecticut", "Massachusetts", "Maryland", "South Carolina", "New Hampshire", "Virginia", "New York", "North Carolina", "Rhode Island", "Vermont", "Kentucky", "Tennessee", "Ohio", "Louisiana", "Indiana", "Mississippi", "Illinois", "Alabama", "Maine", "Missouri", "Arkansas", "Michigan", "Florida", "Texas", "Iowa", "Wisconsin", "California", "Minnesota", "Oregon", "Kansas", "West Virginia", "Nevada", "Nebraska", "Colorado", "North Dakota", "South Dakota", "Montana", "Washington", "Idaho", "Wyoming", "Utah", "Oklahoma", "New Mexico", "Arizona", "Alaska", "Hawaii"})
        Me.lstStates632.Location = New System.Drawing.Point(34, 108)
        Me.lstStates632.Margin = New System.Windows.Forms.Padding(4, 5, 4, 5)
        Me.lstStates632.Name = "lstStates632"
        Me.lstStates632.Size = New System.Drawing.Size(124, 204)
        Me.lstStates632.TabIndex = 3
        '
        'lblStates632
        '
        Me.lblStates632.AutoSize = True
        Me.lblStates632.Location = New System.Drawing.Point(58, 60)
        Me.lblStates632.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.lblStates632.Name = "lblStates632"
        Me.lblStates632.Size = New System.Drawing.Size(60, 20)
        Me.lblStates632.TabIndex = 2
        Me.lblStates632.Text = "States:"
        '
        'gbx633
        '
        Me.gbx633.Controls.Add(Me.txtHighest633)
        Me.gbx633.Controls.Add(Me.txtAverage633)
        Me.gbx633.Controls.Add(Me.txtGrade633)
        Me.gbx633.Controls.Add(Me.lstGrades633)
        Me.gbx633.Controls.Add(Me.lblGrade633)
        Me.gbx633.Controls.Add(Me.lblHighest633)
        Me.gbx633.Controls.Add(Me.lblAverage633)
        Me.gbx633.Controls.Add(Me.btnCalculate633)
        Me.gbx633.Controls.Add(Me.btnRecord633)
        Me.gbx633.Location = New System.Drawing.Point(6, 351)
        Me.gbx633.Margin = New System.Windows.Forms.Padding(4, 5, 4, 5)
        Me.gbx633.Name = "gbx633"
        Me.gbx633.Padding = New System.Windows.Forms.Padding(4, 5, 4, 5)
        Me.gbx633.Size = New System.Drawing.Size(398, 298)
        Me.gbx633.TabIndex = 1
        Me.gbx633.TabStop = False
        Me.gbx633.Text = "EX 6.3.3 - Grades"
        '
        'txtHighest633
        '
        Me.txtHighest633.Location = New System.Drawing.Point(161, 257)
        Me.txtHighest633.Name = "txtHighest633"
        Me.txtHighest633.ReadOnly = True
        Me.txtHighest633.Size = New System.Drawing.Size(64, 26)
        Me.txtHighest633.TabIndex = 8
        '
        'txtAverage633
        '
        Me.txtAverage633.Location = New System.Drawing.Point(161, 214)
        Me.txtAverage633.Name = "txtAverage633"
        Me.txtAverage633.ReadOnly = True
        Me.txtAverage633.Size = New System.Drawing.Size(64, 26)
        Me.txtAverage633.TabIndex = 7
        '
        'txtGrade633
        '
        Me.txtGrade633.Location = New System.Drawing.Point(118, 36)
        Me.txtGrade633.Name = "txtGrade633"
        Me.txtGrade633.Size = New System.Drawing.Size(64, 26)
        Me.txtGrade633.TabIndex = 6
        '
        'lstGrades633
        '
        Me.lstGrades633.FormattingEnabled = True
        Me.lstGrades633.ItemHeight = 20
        Me.lstGrades633.Location = New System.Drawing.Point(248, 36)
        Me.lstGrades633.Margin = New System.Windows.Forms.Padding(4, 5, 4, 5)
        Me.lstGrades633.Name = "lstGrades633"
        Me.lstGrades633.Size = New System.Drawing.Size(124, 244)
        Me.lstGrades633.TabIndex = 5
        '
        'lblGrade633
        '
        Me.lblGrade633.AutoSize = True
        Me.lblGrade633.Location = New System.Drawing.Point(54, 36)
        Me.lblGrade633.Name = "lblGrade633"
        Me.lblGrade633.Size = New System.Drawing.Size(58, 20)
        Me.lblGrade633.TabIndex = 4
        Me.lblGrade633.Text = "Grade:"
        '
        'lblHighest633
        '
        Me.lblHighest633.AutoSize = True
        Me.lblHighest633.Location = New System.Drawing.Point(34, 260)
        Me.lblHighest633.Name = "lblHighest633"
        Me.lblHighest633.Size = New System.Drawing.Size(117, 20)
        Me.lblHighest633.TabIndex = 3
        Me.lblHighest633.Text = "Highest Grade:"
        '
        'lblAverage633
        '
        Me.lblAverage633.AutoSize = True
        Me.lblAverage633.Location = New System.Drawing.Point(34, 220)
        Me.lblAverage633.Name = "lblAverage633"
        Me.lblAverage633.Size = New System.Drawing.Size(121, 20)
        Me.lblAverage633.TabIndex = 2
        Me.lblAverage633.Text = "Average Grade:"
        '
        'btnCalculate633
        '
        Me.btnCalculate633.Location = New System.Drawing.Point(42, 144)
        Me.btnCalculate633.Name = "btnCalculate633"
        Me.btnCalculate633.Size = New System.Drawing.Size(181, 51)
        Me.btnCalculate633.TabIndex = 1
        Me.btnCalculate633.Text = "Calculate Average and Highest Grade"
        Me.btnCalculate633.UseVisualStyleBackColor = True
        '
        'btnRecord633
        '
        Me.btnRecord633.Location = New System.Drawing.Point(42, 93)
        Me.btnRecord633.Name = "btnRecord633"
        Me.btnRecord633.Size = New System.Drawing.Size(181, 45)
        Me.btnRecord633.TabIndex = 0
        Me.btnRecord633.Text = "Record Grade"
        Me.btnRecord633.UseVisualStyleBackColor = True
        '
        'gbx634
        '
        Me.gbx634.Controls.Add(Me.txtOutput634)
        Me.gbx634.Controls.Add(Me.btnSearch634)
        Me.gbx634.Controls.Add(Me.mtbFirstTwoLetters634)
        Me.gbx634.Controls.Add(Me.lblFirstTwo634)
        Me.gbx634.Controls.Add(Me.lstStates634)
        Me.gbx634.Location = New System.Drawing.Point(412, 351)
        Me.gbx634.Margin = New System.Windows.Forms.Padding(4, 5, 4, 5)
        Me.gbx634.Name = "gbx634"
        Me.gbx634.Padding = New System.Windows.Forms.Padding(4, 5, 4, 5)
        Me.gbx634.Size = New System.Drawing.Size(381, 298)
        Me.gbx634.TabIndex = 1
        Me.gbx634.TabStop = False
        Me.gbx634.Text = "EX 6.3.4 - US States"
        '
        'txtOutput634
        '
        Me.txtOutput634.Location = New System.Drawing.Point(178, 220)
        Me.txtOutput634.Margin = New System.Windows.Forms.Padding(4, 5, 4, 5)
        Me.txtOutput634.Name = "txtOutput634"
        Me.txtOutput634.ReadOnly = True
        Me.txtOutput634.Size = New System.Drawing.Size(192, 26)
        Me.txtOutput634.TabIndex = 10
        '
        'btnSearch634
        '
        Me.btnSearch634.Location = New System.Drawing.Point(208, 144)
        Me.btnSearch634.Margin = New System.Windows.Forms.Padding(4, 5, 4, 5)
        Me.btnSearch634.Name = "btnSearch634"
        Me.btnSearch634.Size = New System.Drawing.Size(112, 54)
        Me.btnSearch634.TabIndex = 9
        Me.btnSearch634.Text = "Search for State"
        Me.btnSearch634.UseVisualStyleBackColor = True
        '
        'mtbFirstTwoLetters634
        '
        Me.mtbFirstTwoLetters634.Location = New System.Drawing.Point(286, 62)
        Me.mtbFirstTwoLetters634.Margin = New System.Windows.Forms.Padding(4, 5, 4, 5)
        Me.mtbFirstTwoLetters634.Mask = "LL"
        Me.mtbFirstTwoLetters634.Name = "mtbFirstTwoLetters634"
        Me.mtbFirstTwoLetters634.Size = New System.Drawing.Size(61, 26)
        Me.mtbFirstTwoLetters634.TabIndex = 8
        '
        'lblFirstTwo634
        '
        Me.lblFirstTwo634.Location = New System.Drawing.Point(185, 39)
        Me.lblFirstTwo634.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.lblFirstTwo634.Name = "lblFirstTwo634"
        Me.lblFirstTwo634.Size = New System.Drawing.Size(114, 74)
        Me.lblFirstTwo634.TabIndex = 7
        Me.lblFirstTwo634.Text = "First two letters of state:"
        '
        'lstStates634
        '
        Me.lstStates634.FormattingEnabled = True
        Me.lstStates634.ItemHeight = 20
        Me.lstStates634.Items.AddRange(New Object() {"Alabama", "Alaska", "Arizona", "Arkansas", "California", "Colorado", "Connecticut", "Delaware", "Florida", "Georgia", "Hawaii", "Idaho", "Illinois", "Indiana", "Iowa", "Kansas", "Kentucky", "Louisiana", "Maine", "Maryland", "Massachusetts", "Michigan", "Minnesota", "Mississippi", "Missouri", "Montana", "Nebraska", "Nevada", "New Hampshire", "New Jersey", "New Mexico", "New York", "North Carolina", "North Dakota", "Ohio", "Oklahoma", "Oregon", "Pennsylvania", "Rhode Island", "South Carolina", "South Dakota", "Tennessee", "Texas", "Utah", "Vermont", "Virginia", "Washington", "West Virginia", "Wisconsin", "Wyoming"})
        Me.lstStates634.Location = New System.Drawing.Point(34, 76)
        Me.lstStates634.Margin = New System.Windows.Forms.Padding(4, 5, 4, 5)
        Me.lstStates634.Name = "lstStates634"
        Me.lstStates634.Size = New System.Drawing.Size(124, 204)
        Me.lstStates634.TabIndex = 4
        '
        'SulfaroCH63Lab
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(9.0!, 20.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(812, 668)
        Me.Controls.Add(Me.gbx632)
        Me.Controls.Add(Me.gbx633)
        Me.Controls.Add(Me.gbx634)
        Me.Controls.Add(Me.gbx631)
        Me.Margin = New System.Windows.Forms.Padding(4, 5, 4, 5)
        Me.Name = "SulfaroCH63Lab"
        Me.Text = "Sulfaro CH 6.3 Lab"
        Me.gbx631.ResumeLayout(False)
        Me.gbx631.PerformLayout()
        Me.gbx632.ResumeLayout(False)
        Me.gbx632.PerformLayout()
        Me.gbx633.ResumeLayout(False)
        Me.gbx633.PerformLayout()
        Me.gbx634.ResumeLayout(False)
        Me.gbx634.PerformLayout()
        Me.ResumeLayout(False)

    End Sub

    Friend WithEvents gbx631 As GroupBox
    Friend WithEvents btnDisplay631 As Button
    Friend WithEvents lstLastTen631 As ListBox
    Friend WithEvents lblStates631 As Label
    Friend WithEvents lstStates631 As ListBox
    Friend WithEvents gbx632 As GroupBox
    Friend WithEvents gbx633 As GroupBox
    Friend WithEvents gbx634 As GroupBox
    Friend WithEvents mtbFirstTwoLetters632 As MaskedTextBox
    Friend WithEvents lblFirstTwo632 As Label
    Friend WithEvents btnSearch632 As Button
    Friend WithEvents txtOutput632 As TextBox
    Friend WithEvents lstStates632 As ListBox
    Friend WithEvents lblStates632 As Label
    Friend WithEvents txtHighest633 As TextBox
    Friend WithEvents txtAverage633 As TextBox
    Friend WithEvents txtGrade633 As TextBox
    Friend WithEvents lstGrades633 As ListBox
    Friend WithEvents lblGrade633 As Label
    Friend WithEvents lblHighest633 As Label
    Friend WithEvents lblAverage633 As Label
    Friend WithEvents btnCalculate633 As Button
    Friend WithEvents btnRecord633 As Button
    Friend WithEvents txtOutput634 As TextBox
    Friend WithEvents btnSearch634 As Button
    Friend WithEvents mtbFirstTwoLetters634 As MaskedTextBox
    Friend WithEvents lblFirstTwo634 As Label
    Friend WithEvents lstStates634 As ListBox
End Class
