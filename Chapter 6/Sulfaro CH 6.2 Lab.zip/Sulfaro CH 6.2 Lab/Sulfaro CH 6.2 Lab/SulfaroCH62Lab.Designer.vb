﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class SulfaroCH62Lab
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.gbxEX621Population = New System.Windows.Forms.GroupBox()
        Me.gbxEX622Index = New System.Windows.Forms.GroupBox()
        Me.gbxEX623Backward = New System.Windows.Forms.GroupBox()
        Me.gbxEX624Multiplication = New System.Windows.Forms.GroupBox()
        Me.btnDisplayEX621 = New System.Windows.Forms.Button()
        Me.lstTableEX621 = New System.Windows.Forms.ListBox()
        Me.lblnEX622 = New System.Windows.Forms.Label()
        Me.lblsEX622 = New System.Windows.Forms.Label()
        Me.btnDisplayEX622 = New System.Windows.Forms.Button()
        Me.lstValuesEX622 = New System.Windows.Forms.ListBox()
        Me.txtEndEX622 = New System.Windows.Forms.TextBox()
        Me.txtStepEX622 = New System.Windows.Forms.TextBox()
        Me.lblNEX623 = New System.Windows.Forms.Label()
        Me.txtWordEX623 = New System.Windows.Forms.TextBox()
        Me.btnDisplayEX623 = New System.Windows.Forms.Button()
        Me.txtBackwardEX623 = New System.Windows.Forms.TextBox()
        Me.btnDisplayEX624 = New System.Windows.Forms.Button()
        Me.lstTableEX624 = New System.Windows.Forms.ListBox()
        Me.gbxEX621Population.SuspendLayout()
        Me.gbxEX622Index.SuspendLayout()
        Me.gbxEX623Backward.SuspendLayout()
        Me.gbxEX624Multiplication.SuspendLayout()
        Me.SuspendLayout()
        '
        'gbxEX621Population
        '
        Me.gbxEX621Population.Controls.Add(Me.lstTableEX621)
        Me.gbxEX621Population.Controls.Add(Me.btnDisplayEX621)
        Me.gbxEX621Population.Location = New System.Drawing.Point(12, 12)
        Me.gbxEX621Population.Name = "gbxEX621Population"
        Me.gbxEX621Population.Size = New System.Drawing.Size(258, 198)
        Me.gbxEX621Population.TabIndex = 0
        Me.gbxEX621Population.TabStop = False
        Me.gbxEX621Population.Text = "EX 6.2.1 - Population Growth"
        '
        'gbxEX622Index
        '
        Me.gbxEX622Index.Controls.Add(Me.txtStepEX622)
        Me.gbxEX622Index.Controls.Add(Me.txtEndEX622)
        Me.gbxEX622Index.Controls.Add(Me.lstValuesEX622)
        Me.gbxEX622Index.Controls.Add(Me.btnDisplayEX622)
        Me.gbxEX622Index.Controls.Add(Me.lblsEX622)
        Me.gbxEX622Index.Controls.Add(Me.lblnEX622)
        Me.gbxEX622Index.Location = New System.Drawing.Point(276, 12)
        Me.gbxEX622Index.Name = "gbxEX622Index"
        Me.gbxEX622Index.Size = New System.Drawing.Size(258, 198)
        Me.gbxEX622Index.TabIndex = 0
        Me.gbxEX622Index.TabStop = False
        Me.gbxEX622Index.Text = "EX 6.2.2 - Index Values"
        '
        'gbxEX623Backward
        '
        Me.gbxEX623Backward.Controls.Add(Me.txtBackwardEX623)
        Me.gbxEX623Backward.Controls.Add(Me.btnDisplayEX623)
        Me.gbxEX623Backward.Controls.Add(Me.txtWordEX623)
        Me.gbxEX623Backward.Controls.Add(Me.lblNEX623)
        Me.gbxEX623Backward.Location = New System.Drawing.Point(12, 216)
        Me.gbxEX623Backward.Name = "gbxEX623Backward"
        Me.gbxEX623Backward.Size = New System.Drawing.Size(258, 196)
        Me.gbxEX623Backward.TabIndex = 1
        Me.gbxEX623Backward.TabStop = False
        Me.gbxEX623Backward.Text = "EX 6.2.3 - Write Backward"
        '
        'gbxEX624Multiplication
        '
        Me.gbxEX624Multiplication.Controls.Add(Me.lstTableEX624)
        Me.gbxEX624Multiplication.Controls.Add(Me.btnDisplayEX624)
        Me.gbxEX624Multiplication.Location = New System.Drawing.Point(276, 216)
        Me.gbxEX624Multiplication.Name = "gbxEX624Multiplication"
        Me.gbxEX624Multiplication.Size = New System.Drawing.Size(258, 196)
        Me.gbxEX624Multiplication.TabIndex = 1
        Me.gbxEX624Multiplication.TabStop = False
        Me.gbxEX624Multiplication.Text = "EX 6.2.4 - Multiplication"
        '
        'btnDisplayEX621
        '
        Me.btnDisplayEX621.Location = New System.Drawing.Point(55, 37)
        Me.btnDisplayEX621.Name = "btnDisplayEX621"
        Me.btnDisplayEX621.Size = New System.Drawing.Size(120, 23)
        Me.btnDisplayEX621.TabIndex = 0
        Me.btnDisplayEX621.Text = "Display Population"
        Me.btnDisplayEX621.UseVisualStyleBackColor = True
        '
        'lstTableEX621
        '
        Me.lstTableEX621.Font = New System.Drawing.Font("Courier New", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lstTableEX621.FormattingEnabled = True
        Me.lstTableEX621.ItemHeight = 14
        Me.lstTableEX621.Location = New System.Drawing.Point(55, 87)
        Me.lstTableEX621.Name = "lstTableEX621"
        Me.lstTableEX621.Size = New System.Drawing.Size(120, 88)
        Me.lstTableEX621.TabIndex = 1
        '
        'lblnEX622
        '
        Me.lblnEX622.AutoSize = True
        Me.lblnEX622.Location = New System.Drawing.Point(31, 30)
        Me.lblnEX622.Name = "lblnEX622"
        Me.lblnEX622.Size = New System.Drawing.Size(16, 13)
        Me.lblnEX622.TabIndex = 0
        Me.lblnEX622.Text = "n:"
        '
        'lblsEX622
        '
        Me.lblsEX622.AutoSize = True
        Me.lblsEX622.Location = New System.Drawing.Point(157, 33)
        Me.lblsEX622.Name = "lblsEX622"
        Me.lblsEX622.Size = New System.Drawing.Size(15, 13)
        Me.lblsEX622.TabIndex = 1
        Me.lblsEX622.Text = "s:"
        '
        'btnDisplayEX622
        '
        Me.btnDisplayEX622.Location = New System.Drawing.Point(53, 65)
        Me.btnDisplayEX622.Name = "btnDisplayEX622"
        Me.btnDisplayEX622.Size = New System.Drawing.Size(141, 23)
        Me.btnDisplayEX622.TabIndex = 2
        Me.btnDisplayEX622.Text = "Display Values of Index"
        Me.btnDisplayEX622.UseVisualStyleBackColor = True
        '
        'lstValuesEX622
        '
        Me.lstValuesEX622.Font = New System.Drawing.Font("Courier New", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lstValuesEX622.FormattingEnabled = True
        Me.lstValuesEX622.ItemHeight = 14
        Me.lstValuesEX622.Location = New System.Drawing.Point(65, 94)
        Me.lstValuesEX622.Name = "lstValuesEX622"
        Me.lstValuesEX622.Size = New System.Drawing.Size(120, 88)
        Me.lstValuesEX622.TabIndex = 3
        '
        'txtEndEX622
        '
        Me.txtEndEX622.Location = New System.Drawing.Point(53, 30)
        Me.txtEndEX622.Name = "txtEndEX622"
        Me.txtEndEX622.Size = New System.Drawing.Size(40, 20)
        Me.txtEndEX622.TabIndex = 4
        '
        'txtStepEX622
        '
        Me.txtStepEX622.Location = New System.Drawing.Point(178, 30)
        Me.txtStepEX622.Name = "txtStepEX622"
        Me.txtStepEX622.Size = New System.Drawing.Size(40, 20)
        Me.txtStepEX622.TabIndex = 5
        '
        'lblNEX623
        '
        Me.lblNEX623.AutoSize = True
        Me.lblNEX623.Location = New System.Drawing.Point(16, 40)
        Me.lblNEX623.Name = "lblNEX623"
        Me.lblNEX623.Size = New System.Drawing.Size(61, 13)
        Me.lblNEX623.TabIndex = 0
        Me.lblNEX623.Text = "Enter word:"
        '
        'txtWordEX623
        '
        Me.txtWordEX623.Location = New System.Drawing.Point(84, 37)
        Me.txtWordEX623.Name = "txtWordEX623"
        Me.txtWordEX623.Size = New System.Drawing.Size(100, 20)
        Me.txtWordEX623.TabIndex = 1
        '
        'btnDisplayEX623
        '
        Me.btnDisplayEX623.Location = New System.Drawing.Point(69, 86)
        Me.btnDisplayEX623.Name = "btnDisplayEX623"
        Me.btnDisplayEX623.Size = New System.Drawing.Size(115, 23)
        Me.btnDisplayEX623.TabIndex = 2
        Me.btnDisplayEX623.Text = "Reverse Letters"
        Me.btnDisplayEX623.UseVisualStyleBackColor = True
        '
        'txtBackwardEX623
        '
        Me.txtBackwardEX623.Location = New System.Drawing.Point(75, 147)
        Me.txtBackwardEX623.Name = "txtBackwardEX623"
        Me.txtBackwardEX623.ReadOnly = True
        Me.txtBackwardEX623.Size = New System.Drawing.Size(100, 20)
        Me.txtBackwardEX623.TabIndex = 3
        '
        'btnDisplayEX624
        '
        Me.btnDisplayEX624.Location = New System.Drawing.Point(65, 20)
        Me.btnDisplayEX624.Name = "btnDisplayEX624"
        Me.btnDisplayEX624.Size = New System.Drawing.Size(153, 23)
        Me.btnDisplayEX624.TabIndex = 0
        Me.btnDisplayEX624.Text = "Display Multiplication Table"
        Me.btnDisplayEX624.UseVisualStyleBackColor = True
        '
        'lstTableEX624
        '
        Me.lstTableEX624.Font = New System.Drawing.Font("Courier New", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lstTableEX624.FormattingEnabled = True
        Me.lstTableEX624.ItemHeight = 14
        Me.lstTableEX624.Location = New System.Drawing.Point(6, 49)
        Me.lstTableEX624.Name = "lstTableEX624"
        Me.lstTableEX624.Size = New System.Drawing.Size(246, 130)
        Me.lstTableEX624.TabIndex = 1
        '
        'SulfaroCH62Lab
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(546, 424)
        Me.Controls.Add(Me.gbxEX622Index)
        Me.Controls.Add(Me.gbxEX623Backward)
        Me.Controls.Add(Me.gbxEX624Multiplication)
        Me.Controls.Add(Me.gbxEX621Population)
        Me.Name = "SulfaroCH62Lab"
        Me.Text = "Sulfaro CH 6.2 Lab"
        Me.gbxEX621Population.ResumeLayout(False)
        Me.gbxEX622Index.ResumeLayout(False)
        Me.gbxEX622Index.PerformLayout()
        Me.gbxEX623Backward.ResumeLayout(False)
        Me.gbxEX623Backward.PerformLayout()
        Me.gbxEX624Multiplication.ResumeLayout(False)
        Me.ResumeLayout(False)

    End Sub

    Friend WithEvents gbxEX621Population As GroupBox
    Friend WithEvents lstTableEX621 As ListBox
    Friend WithEvents btnDisplayEX621 As Button
    Friend WithEvents gbxEX622Index As GroupBox
    Friend WithEvents gbxEX623Backward As GroupBox
    Friend WithEvents gbxEX624Multiplication As GroupBox
    Friend WithEvents txtStepEX622 As TextBox
    Friend WithEvents txtEndEX622 As TextBox
    Friend WithEvents lstValuesEX622 As ListBox
    Friend WithEvents btnDisplayEX622 As Button
    Friend WithEvents lblsEX622 As Label
    Friend WithEvents lblnEX622 As Label
    Friend WithEvents txtBackwardEX623 As TextBox
    Friend WithEvents btnDisplayEX623 As Button
    Friend WithEvents txtWordEX623 As TextBox
    Friend WithEvents lblNEX623 As Label
    Friend WithEvents lstTableEX624 As ListBox
    Friend WithEvents btnDisplayEX624 As Button
End Class
