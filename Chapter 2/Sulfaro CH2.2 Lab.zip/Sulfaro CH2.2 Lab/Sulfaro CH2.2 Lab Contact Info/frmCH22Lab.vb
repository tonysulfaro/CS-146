﻿Public Class frmCH22Lab
    Private Sub Label1_Click(sender As Object, e As EventArgs) Handles lblCityStateZip.Click

    End Sub

    Private Sub lblPhone_Click(sender As Object, e As EventArgs) Handles lblPhone.Click

    End Sub

    Private Sub ListBox1_SelectedIndexChanged(sender As Object, e As EventArgs) Handles lstOutput.SelectedIndexChanged

    End Sub
End Class
