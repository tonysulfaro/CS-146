﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class frmSulfaroCH23HW
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.gbxText33 = New System.Windows.Forms.GroupBox()
        Me.txtAllignText33 = New System.Windows.Forms.TextBox()
        Me.btnRightJustify33 = New System.Windows.Forms.Button()
        Me.btnCenter33 = New System.Windows.Forms.Button()
        Me.btnLeftJustify33 = New System.Windows.Forms.Button()
        Me.gbxFace34 = New System.Windows.Forms.GroupBox()
        Me.gbxColorful35 = New System.Windows.Forms.GroupBox()
        Me.gbxOneTwoThree36 = New System.Windows.Forms.GroupBox()
        Me.lblFace34 = New System.Windows.Forms.Label()
        Me.btnSmile34 = New System.Windows.Forms.Button()
        Me.btnFrown34 = New System.Windows.Forms.Button()
        Me.btnRed35 = New System.Windows.Forms.Button()
        Me.btnWhite35 = New System.Windows.Forms.Button()
        Me.btnBlue35 = New System.Windows.Forms.Button()
        Me.btnYellow35 = New System.Windows.Forms.Button()
        Me.txtOne36 = New System.Windows.Forms.TextBox()
        Me.lblBack35 = New System.Windows.Forms.Label()
        Me.lblFore35 = New System.Windows.Forms.Label()
        Me.Button1 = New System.Windows.Forms.Button()
        Me.Button2 = New System.Windows.Forms.Button()
        Me.txtTwo36 = New System.Windows.Forms.TextBox()
        Me.txtThree36 = New System.Windows.Forms.TextBox()
        Me.txtBox35 = New System.Windows.Forms.TextBox()
        Me.gbxText33.SuspendLayout()
        Me.gbxFace34.SuspendLayout()
        Me.gbxColorful35.SuspendLayout()
        Me.gbxOneTwoThree36.SuspendLayout()
        Me.SuspendLayout()
        '
        'gbxText33
        '
        Me.gbxText33.Controls.Add(Me.txtAllignText33)
        Me.gbxText33.Controls.Add(Me.btnRightJustify33)
        Me.gbxText33.Controls.Add(Me.btnCenter33)
        Me.gbxText33.Controls.Add(Me.btnLeftJustify33)
        Me.gbxText33.Location = New System.Drawing.Point(12, 12)
        Me.gbxText33.Name = "gbxText33"
        Me.gbxText33.Size = New System.Drawing.Size(334, 218)
        Me.gbxText33.TabIndex = 0
        Me.gbxText33.TabStop = False
        Me.gbxText33.Text = "Allign Text"
        '
        'txtAllignText33
        '
        Me.txtAllignText33.Location = New System.Drawing.Point(53, 73)
        Me.txtAllignText33.Name = "txtAllignText33"
        Me.txtAllignText33.Size = New System.Drawing.Size(222, 20)
        Me.txtAllignText33.TabIndex = 3
        '
        'btnRightJustify33
        '
        Me.btnRightJustify33.Location = New System.Drawing.Point(253, 166)
        Me.btnRightJustify33.Name = "btnRightJustify33"
        Me.btnRightJustify33.Size = New System.Drawing.Size(75, 23)
        Me.btnRightJustify33.TabIndex = 2
        Me.btnRightJustify33.Text = "Right Justify"
        Me.btnRightJustify33.UseVisualStyleBackColor = True
        '
        'btnCenter33
        '
        Me.btnCenter33.Location = New System.Drawing.Point(133, 166)
        Me.btnCenter33.Name = "btnCenter33"
        Me.btnCenter33.Size = New System.Drawing.Size(75, 23)
        Me.btnCenter33.TabIndex = 1
        Me.btnCenter33.Text = "Center"
        Me.btnCenter33.UseVisualStyleBackColor = True
        '
        'btnLeftJustify33
        '
        Me.btnLeftJustify33.Location = New System.Drawing.Point(6, 166)
        Me.btnLeftJustify33.Name = "btnLeftJustify33"
        Me.btnLeftJustify33.Size = New System.Drawing.Size(75, 23)
        Me.btnLeftJustify33.TabIndex = 0
        Me.btnLeftJustify33.Text = "Left Justify"
        Me.btnLeftJustify33.UseVisualStyleBackColor = True
        '
        'gbxFace34
        '
        Me.gbxFace34.Controls.Add(Me.btnFrown34)
        Me.gbxFace34.Controls.Add(Me.btnSmile34)
        Me.gbxFace34.Controls.Add(Me.lblFace34)
        Me.gbxFace34.Location = New System.Drawing.Point(374, 12)
        Me.gbxFace34.Name = "gbxFace34"
        Me.gbxFace34.Size = New System.Drawing.Size(330, 218)
        Me.gbxFace34.TabIndex = 0
        Me.gbxFace34.TabStop = False
        Me.gbxFace34.Text = "GroupBox2"
        '
        'gbxColorful35
        '
        Me.gbxColorful35.Controls.Add(Me.txtBox35)
        Me.gbxColorful35.Controls.Add(Me.lblFore35)
        Me.gbxColorful35.Controls.Add(Me.lblBack35)
        Me.gbxColorful35.Controls.Add(Me.btnYellow35)
        Me.gbxColorful35.Controls.Add(Me.btnBlue35)
        Me.gbxColorful35.Controls.Add(Me.btnWhite35)
        Me.gbxColorful35.Controls.Add(Me.btnRed35)
        Me.gbxColorful35.Location = New System.Drawing.Point(12, 236)
        Me.gbxColorful35.Name = "gbxColorful35"
        Me.gbxColorful35.Size = New System.Drawing.Size(334, 251)
        Me.gbxColorful35.TabIndex = 0
        Me.gbxColorful35.TabStop = False
        Me.gbxColorful35.Text = "GroupBox3"
        '
        'gbxOneTwoThree36
        '
        Me.gbxOneTwoThree36.Controls.Add(Me.txtThree36)
        Me.gbxOneTwoThree36.Controls.Add(Me.txtTwo36)
        Me.gbxOneTwoThree36.Controls.Add(Me.Button2)
        Me.gbxOneTwoThree36.Controls.Add(Me.txtOne36)
        Me.gbxOneTwoThree36.Controls.Add(Me.Button1)
        Me.gbxOneTwoThree36.Location = New System.Drawing.Point(374, 236)
        Me.gbxOneTwoThree36.Name = "gbxOneTwoThree36"
        Me.gbxOneTwoThree36.Size = New System.Drawing.Size(330, 251)
        Me.gbxOneTwoThree36.TabIndex = 0
        Me.gbxOneTwoThree36.TabStop = False
        Me.gbxOneTwoThree36.Text = "1, 2, 3"
        '
        'lblFace34
        '
        Me.lblFace34.AutoSize = True
        Me.lblFace34.Location = New System.Drawing.Point(79, 57)
        Me.lblFace34.Name = "lblFace34"
        Me.lblFace34.Size = New System.Drawing.Size(75, 13)
        Me.lblFace34.TabIndex = 0
        Me.lblFace34.Text = "insert shit here"
        '
        'btnSmile34
        '
        Me.btnSmile34.Location = New System.Drawing.Point(36, 165)
        Me.btnSmile34.Name = "btnSmile34"
        Me.btnSmile34.Size = New System.Drawing.Size(75, 23)
        Me.btnSmile34.TabIndex = 1
        Me.btnSmile34.Text = "Button1"
        Me.btnSmile34.UseVisualStyleBackColor = True
        '
        'btnFrown34
        '
        Me.btnFrown34.Location = New System.Drawing.Point(214, 165)
        Me.btnFrown34.Name = "btnFrown34"
        Me.btnFrown34.Size = New System.Drawing.Size(75, 23)
        Me.btnFrown34.TabIndex = 2
        Me.btnFrown34.Text = "Button1"
        Me.btnFrown34.UseVisualStyleBackColor = True
        '
        'btnRed35
        '
        Me.btnRed35.Location = New System.Drawing.Point(89, 34)
        Me.btnRed35.Name = "btnRed35"
        Me.btnRed35.Size = New System.Drawing.Size(75, 23)
        Me.btnRed35.TabIndex = 0
        Me.btnRed35.Text = "Button1"
        Me.btnRed35.UseVisualStyleBackColor = True
        '
        'btnWhite35
        '
        Me.btnWhite35.Location = New System.Drawing.Point(89, 198)
        Me.btnWhite35.Name = "btnWhite35"
        Me.btnWhite35.Size = New System.Drawing.Size(75, 23)
        Me.btnWhite35.TabIndex = 1
        Me.btnWhite35.Text = "Button2"
        Me.btnWhite35.UseVisualStyleBackColor = True
        '
        'btnBlue35
        '
        Me.btnBlue35.Location = New System.Drawing.Point(209, 34)
        Me.btnBlue35.Name = "btnBlue35"
        Me.btnBlue35.Size = New System.Drawing.Size(75, 23)
        Me.btnBlue35.TabIndex = 2
        Me.btnBlue35.Text = "Button3"
        Me.btnBlue35.UseVisualStyleBackColor = True
        '
        'btnYellow35
        '
        Me.btnYellow35.Location = New System.Drawing.Point(209, 198)
        Me.btnYellow35.Name = "btnYellow35"
        Me.btnYellow35.Size = New System.Drawing.Size(75, 23)
        Me.btnYellow35.TabIndex = 3
        Me.btnYellow35.Text = "Button4"
        Me.btnYellow35.UseVisualStyleBackColor = True
        '
        'txtOne36
        '
        Me.txtOne36.Location = New System.Drawing.Point(11, 61)
        Me.txtOne36.Name = "txtOne36"
        Me.txtOne36.Size = New System.Drawing.Size(170, 20)
        Me.txtOne36.TabIndex = 4
        '
        'lblBack35
        '
        Me.lblBack35.AutoSize = True
        Me.lblBack35.Location = New System.Drawing.Point(0, 39)
        Me.lblBack35.Name = "lblBack35"
        Me.lblBack35.Size = New System.Drawing.Size(39, 13)
        Me.lblBack35.TabIndex = 5
        Me.lblBack35.Text = "Label1"
        '
        'lblFore35
        '
        Me.lblFore35.AutoSize = True
        Me.lblFore35.Location = New System.Drawing.Point(0, 203)
        Me.lblFore35.Name = "lblFore35"
        Me.lblFore35.Size = New System.Drawing.Size(39, 13)
        Me.lblFore35.TabIndex = 6
        Me.lblFore35.Text = "Label2"
        '
        'Button1
        '
        Me.Button1.Location = New System.Drawing.Point(214, 61)
        Me.Button1.Name = "Button1"
        Me.Button1.Size = New System.Drawing.Size(75, 23)
        Me.Button1.TabIndex = 0
        Me.Button1.Text = "Button1"
        Me.Button1.UseVisualStyleBackColor = True
        '
        'Button2
        '
        Me.Button2.Location = New System.Drawing.Point(214, 201)
        Me.Button2.Name = "Button2"
        Me.Button2.Size = New System.Drawing.Size(75, 23)
        Me.Button2.TabIndex = 1
        Me.Button2.Text = "Button2"
        Me.Button2.UseVisualStyleBackColor = True
        '
        'txtTwo36
        '
        Me.txtTwo36.Location = New System.Drawing.Point(11, 138)
        Me.txtTwo36.Name = "txtTwo36"
        Me.txtTwo36.Size = New System.Drawing.Size(170, 20)
        Me.txtTwo36.TabIndex = 2
        '
        'txtThree36
        '
        Me.txtThree36.Location = New System.Drawing.Point(11, 204)
        Me.txtThree36.Name = "txtThree36"
        Me.txtThree36.Size = New System.Drawing.Size(170, 20)
        Me.txtThree36.TabIndex = 3
        '
        'txtBox35
        '
        Me.txtBox35.Location = New System.Drawing.Point(105, 127)
        Me.txtBox35.Name = "txtBox35"
        Me.txtBox35.Size = New System.Drawing.Size(170, 20)
        Me.txtBox35.TabIndex = 4
        '
        'frmSulfaroCH23HW
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(716, 499)
        Me.Controls.Add(Me.gbxFace34)
        Me.Controls.Add(Me.gbxColorful35)
        Me.Controls.Add(Me.gbxOneTwoThree36)
        Me.Controls.Add(Me.gbxText33)
        Me.Name = "frmSulfaroCH23HW"
        Me.Text = "Form1"
        Me.gbxText33.ResumeLayout(False)
        Me.gbxText33.PerformLayout()
        Me.gbxFace34.ResumeLayout(False)
        Me.gbxFace34.PerformLayout()
        Me.gbxColorful35.ResumeLayout(False)
        Me.gbxColorful35.PerformLayout()
        Me.gbxOneTwoThree36.ResumeLayout(False)
        Me.gbxOneTwoThree36.PerformLayout()
        Me.ResumeLayout(False)

    End Sub

    Friend WithEvents gbxText33 As GroupBox
    Friend WithEvents txtAllignText33 As TextBox
    Friend WithEvents btnRightJustify33 As Button
    Friend WithEvents btnCenter33 As Button
    Friend WithEvents btnLeftJustify33 As Button
    Friend WithEvents gbxFace34 As GroupBox
    Friend WithEvents gbxColorful35 As GroupBox
    Friend WithEvents gbxOneTwoThree36 As GroupBox
    Friend WithEvents btnFrown34 As Button
    Friend WithEvents btnSmile34 As Button
    Friend WithEvents lblFace34 As Label
    Friend WithEvents lblFore35 As Label
    Friend WithEvents lblBack35 As Label
    Friend WithEvents txtOne36 As TextBox
    Friend WithEvents btnYellow35 As Button
    Friend WithEvents btnBlue35 As Button
    Friend WithEvents btnWhite35 As Button
    Friend WithEvents btnRed35 As Button
    Friend WithEvents txtBox35 As TextBox
    Friend WithEvents txtThree36 As TextBox
    Friend WithEvents txtTwo36 As TextBox
    Friend WithEvents Button2 As Button
    Friend WithEvents Button1 As Button
End Class
