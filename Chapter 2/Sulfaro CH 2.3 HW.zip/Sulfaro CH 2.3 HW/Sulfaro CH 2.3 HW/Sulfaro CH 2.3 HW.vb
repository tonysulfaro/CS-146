﻿Public Class frmSulfaroCH23HW

    'Program: CH 2.3HW
    'Name:    Anthony Sulfaro
    'Date:    9/13/16
    'Class:   CS 146.04
    'Program purpose: Program to learn about vb events.

    'Homework # 33
    Private Sub btnLeftJustify33_Click(sender As Object, e As EventArgs) Handles btnLeftJustify33.Click
        txtAllignText33.TextAlign = HorizontalAlignment.Left
        txtAllignText33.Text = "Left Justify"
    End Sub

    Private Sub btnCenter33_Click(sender As Object, e As EventArgs) Handles btnCenter33.Click
        txtAllignText33.TextAlign = HorizontalAlignment.Center
        txtAllignText33.Text = "Center"
    End Sub

    Private Sub btnRightJustify33_Click(sender As Object, e As EventArgs) Handles btnRightJustify33.Click
        txtAllignText33.TextAlign = HorizontalAlignment.Right
        txtAllignText33.Text = "Right Justified"
    End Sub


    'Homework # 34
    Private Sub btnSmile34_Click(sender As Object, e As EventArgs) Handles btnSmile34.Click
        lblFace34.Text = ":-)"
    End Sub

    Private Sub btnFrown34_Click(sender As Object, e As EventArgs) Handles btnFrown34.Click
        lblFace34.Text = ":-("
    End Sub


    'Homework # 35
    Private Sub btnRed35_Click(sender As Object, e As EventArgs) Handles btnRed35.Click
        txtBox35.BackColor = Color.Red
    End Sub

    Private Sub btnBlue35_Click(sender As Object, e As EventArgs) Handles btnBlue35.Click
        txtBox35.BackColor = Color.Blue
    End Sub

    Private Sub btnWhite35_Click(sender As Object, e As EventArgs) Handles btnWhite35.Click
        txtBox35.ForeColor = Color.White
    End Sub

    Private Sub btnYellow35_Click(sender As Object, e As EventArgs) Handles btnYellow35.Click
        txtBox35.ForeColor = Color.Yellow
    End Sub


    'Homework # 36
    Private Sub txtOne36_Enter(sender As Object, e As EventArgs) Handles txtOne36.Enter
        txtOne36.ForeColor = Color.Red
        txtTwo36.ForeColor = Color.Black
        txtThree36.ForeColor = Color.Black
    End Sub

    Private Sub txtTwo36_Enter(sender As Object, e As EventArgs) Handles txtTwo36.Enter
        txtTwo36.ForeColor = Color.Red
        txtOne36.ForeColor = Color.Black
        txtThree36.ForeColor = Color.Black
    End Sub

    Private Sub txtThree36_Enter(sender As Object, e As EventArgs) Handles txtThree36.Enter
        txtThree36.ForeColor = Color.Red
        txtOne36.ForeColor = Color.Black
        txtTwo36.ForeColor = Color.Black

    End Sub

    Private Sub btnLeft36_Click(sender As Object, e As EventArgs) Handles btnLeft36.Click
        txtOne36.TextAlign = HorizontalAlignment.Left
        txtTwo36.TextAlign = HorizontalAlignment.Left
        txtThree36.TextAlign = HorizontalAlignment.Left
    End Sub

    Private Sub brnRight36_Click(sender As Object, e As EventArgs) Handles brnRight36.Click
        txtOne36.TextAlign = HorizontalAlignment.Right
        txtTwo36.TextAlign = HorizontalAlignment.Right
        txtThree36.TextAlign = HorizontalAlignment.Right
    End Sub


End Class
