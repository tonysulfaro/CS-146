﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class frmSulfaroCH23HW
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.gbxText33 = New System.Windows.Forms.GroupBox()
        Me.txtAllignText33 = New System.Windows.Forms.TextBox()
        Me.btnRightJustify33 = New System.Windows.Forms.Button()
        Me.btnCenter33 = New System.Windows.Forms.Button()
        Me.btnLeftJustify33 = New System.Windows.Forms.Button()
        Me.gbxFace34 = New System.Windows.Forms.GroupBox()
        Me.btnFrown34 = New System.Windows.Forms.Button()
        Me.btnSmile34 = New System.Windows.Forms.Button()
        Me.lblFace34 = New System.Windows.Forms.Label()
        Me.gbxColorful35 = New System.Windows.Forms.GroupBox()
        Me.txtBox35 = New System.Windows.Forms.TextBox()
        Me.lblFore35 = New System.Windows.Forms.Label()
        Me.lblBack35 = New System.Windows.Forms.Label()
        Me.btnYellow35 = New System.Windows.Forms.Button()
        Me.btnBlue35 = New System.Windows.Forms.Button()
        Me.btnWhite35 = New System.Windows.Forms.Button()
        Me.btnRed35 = New System.Windows.Forms.Button()
        Me.gbxOneTwoThree36 = New System.Windows.Forms.GroupBox()
        Me.txtThree36 = New System.Windows.Forms.TextBox()
        Me.txtTwo36 = New System.Windows.Forms.TextBox()
        Me.brnRight36 = New System.Windows.Forms.Button()
        Me.txtOne36 = New System.Windows.Forms.TextBox()
        Me.btnLeft36 = New System.Windows.Forms.Button()
        Me.gbxText33.SuspendLayout()
        Me.gbxFace34.SuspendLayout()
        Me.gbxColorful35.SuspendLayout()
        Me.gbxOneTwoThree36.SuspendLayout()
        Me.SuspendLayout()
        '
        'gbxText33
        '
        Me.gbxText33.Controls.Add(Me.txtAllignText33)
        Me.gbxText33.Controls.Add(Me.btnRightJustify33)
        Me.gbxText33.Controls.Add(Me.btnCenter33)
        Me.gbxText33.Controls.Add(Me.btnLeftJustify33)
        Me.gbxText33.Location = New System.Drawing.Point(12, 12)
        Me.gbxText33.Name = "gbxText33"
        Me.gbxText33.Size = New System.Drawing.Size(334, 218)
        Me.gbxText33.TabIndex = 0
        Me.gbxText33.TabStop = False
        Me.gbxText33.Text = "EX33 Allign Text"
        '
        'txtAllignText33
        '
        Me.txtAllignText33.Location = New System.Drawing.Point(53, 73)
        Me.txtAllignText33.Name = "txtAllignText33"
        Me.txtAllignText33.Size = New System.Drawing.Size(222, 20)
        Me.txtAllignText33.TabIndex = 3
        '
        'btnRightJustify33
        '
        Me.btnRightJustify33.Location = New System.Drawing.Point(221, 125)
        Me.btnRightJustify33.Name = "btnRightJustify33"
        Me.btnRightJustify33.Size = New System.Drawing.Size(75, 23)
        Me.btnRightJustify33.TabIndex = 2
        Me.btnRightJustify33.Text = "Right Justify"
        Me.btnRightJustify33.UseVisualStyleBackColor = True
        '
        'btnCenter33
        '
        Me.btnCenter33.Location = New System.Drawing.Point(123, 125)
        Me.btnCenter33.Name = "btnCenter33"
        Me.btnCenter33.Size = New System.Drawing.Size(75, 23)
        Me.btnCenter33.TabIndex = 1
        Me.btnCenter33.Text = "Center"
        Me.btnCenter33.UseVisualStyleBackColor = True
        '
        'btnLeftJustify33
        '
        Me.btnLeftJustify33.Location = New System.Drawing.Point(22, 125)
        Me.btnLeftJustify33.Name = "btnLeftJustify33"
        Me.btnLeftJustify33.Size = New System.Drawing.Size(75, 23)
        Me.btnLeftJustify33.TabIndex = 0
        Me.btnLeftJustify33.Text = "Left Justify"
        Me.btnLeftJustify33.UseVisualStyleBackColor = True
        '
        'gbxFace34
        '
        Me.gbxFace34.Controls.Add(Me.btnFrown34)
        Me.gbxFace34.Controls.Add(Me.btnSmile34)
        Me.gbxFace34.Controls.Add(Me.lblFace34)
        Me.gbxFace34.Location = New System.Drawing.Point(374, 12)
        Me.gbxFace34.Name = "gbxFace34"
        Me.gbxFace34.Size = New System.Drawing.Size(330, 218)
        Me.gbxFace34.TabIndex = 0
        Me.gbxFace34.TabStop = False
        Me.gbxFace34.Text = "EX34 Face"
        '
        'btnFrown34
        '
        Me.btnFrown34.Location = New System.Drawing.Point(214, 165)
        Me.btnFrown34.Name = "btnFrown34"
        Me.btnFrown34.Size = New System.Drawing.Size(75, 23)
        Me.btnFrown34.TabIndex = 2
        Me.btnFrown34.Text = "Frown"
        Me.btnFrown34.UseVisualStyleBackColor = True
        '
        'btnSmile34
        '
        Me.btnSmile34.Location = New System.Drawing.Point(36, 165)
        Me.btnSmile34.Name = "btnSmile34"
        Me.btnSmile34.Size = New System.Drawing.Size(75, 23)
        Me.btnSmile34.TabIndex = 1
        Me.btnSmile34.Text = "Smile"
        Me.btnSmile34.UseVisualStyleBackColor = True
        '
        'lblFace34
        '
        Me.lblFace34.AutoSize = True
        Me.lblFace34.Font = New System.Drawing.Font("Microsoft Sans Serif", 21.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblFace34.Location = New System.Drawing.Point(137, 73)
        Me.lblFace34.Name = "lblFace34"
        Me.lblFace34.Size = New System.Drawing.Size(44, 33)
        Me.lblFace34.TabIndex = 0
        Me.lblFace34.Text = ":-|"
        '
        'gbxColorful35
        '
        Me.gbxColorful35.Controls.Add(Me.txtBox35)
        Me.gbxColorful35.Controls.Add(Me.lblFore35)
        Me.gbxColorful35.Controls.Add(Me.lblBack35)
        Me.gbxColorful35.Controls.Add(Me.btnYellow35)
        Me.gbxColorful35.Controls.Add(Me.btnBlue35)
        Me.gbxColorful35.Controls.Add(Me.btnWhite35)
        Me.gbxColorful35.Controls.Add(Me.btnRed35)
        Me.gbxColorful35.Location = New System.Drawing.Point(12, 236)
        Me.gbxColorful35.Name = "gbxColorful35"
        Me.gbxColorful35.Size = New System.Drawing.Size(334, 251)
        Me.gbxColorful35.TabIndex = 0
        Me.gbxColorful35.TabStop = False
        Me.gbxColorful35.Text = "EX35 Colorful Text"
        '
        'txtBox35
        '
        Me.txtBox35.Location = New System.Drawing.Point(16, 127)
        Me.txtBox35.Name = "txtBox35"
        Me.txtBox35.Size = New System.Drawing.Size(275, 20)
        Me.txtBox35.TabIndex = 4
        Me.txtBox35.Text = "Beautiful Day"
        Me.txtBox35.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        '
        'lblFore35
        '
        Me.lblFore35.AutoSize = True
        Me.lblFore35.Location = New System.Drawing.Point(19, 177)
        Me.lblFore35.Name = "lblFore35"
        Me.lblFore35.Size = New System.Drawing.Size(61, 13)
        Me.lblFore35.TabIndex = 6
        Me.lblFore35.Text = "Foreground"
        '
        'lblBack35
        '
        Me.lblBack35.AutoSize = True
        Me.lblBack35.Location = New System.Drawing.Point(17, 60)
        Me.lblBack35.Name = "lblBack35"
        Me.lblBack35.Size = New System.Drawing.Size(65, 13)
        Me.lblBack35.TabIndex = 5
        Me.lblBack35.Text = "Background"
        '
        'btnYellow35
        '
        Me.btnYellow35.Location = New System.Drawing.Point(209, 174)
        Me.btnYellow35.Name = "btnYellow35"
        Me.btnYellow35.Size = New System.Drawing.Size(75, 23)
        Me.btnYellow35.TabIndex = 3
        Me.btnYellow35.Text = "Yellow"
        Me.btnYellow35.UseVisualStyleBackColor = True
        '
        'btnBlue35
        '
        Me.btnBlue35.Location = New System.Drawing.Point(209, 56)
        Me.btnBlue35.Name = "btnBlue35"
        Me.btnBlue35.Size = New System.Drawing.Size(75, 23)
        Me.btnBlue35.TabIndex = 2
        Me.btnBlue35.Text = "Blue"
        Me.btnBlue35.UseVisualStyleBackColor = True
        '
        'btnWhite35
        '
        Me.btnWhite35.Location = New System.Drawing.Point(89, 174)
        Me.btnWhite35.Name = "btnWhite35"
        Me.btnWhite35.Size = New System.Drawing.Size(75, 23)
        Me.btnWhite35.TabIndex = 1
        Me.btnWhite35.Text = "White"
        Me.btnWhite35.UseVisualStyleBackColor = True
        '
        'btnRed35
        '
        Me.btnRed35.Location = New System.Drawing.Point(89, 56)
        Me.btnRed35.Name = "btnRed35"
        Me.btnRed35.Size = New System.Drawing.Size(75, 23)
        Me.btnRed35.TabIndex = 0
        Me.btnRed35.Text = "Red"
        Me.btnRed35.UseVisualStyleBackColor = True
        '
        'gbxOneTwoThree36
        '
        Me.gbxOneTwoThree36.Controls.Add(Me.txtThree36)
        Me.gbxOneTwoThree36.Controls.Add(Me.txtTwo36)
        Me.gbxOneTwoThree36.Controls.Add(Me.brnRight36)
        Me.gbxOneTwoThree36.Controls.Add(Me.txtOne36)
        Me.gbxOneTwoThree36.Controls.Add(Me.btnLeft36)
        Me.gbxOneTwoThree36.Location = New System.Drawing.Point(374, 236)
        Me.gbxOneTwoThree36.Name = "gbxOneTwoThree36"
        Me.gbxOneTwoThree36.Size = New System.Drawing.Size(330, 251)
        Me.gbxOneTwoThree36.TabIndex = 0
        Me.gbxOneTwoThree36.TabStop = False
        Me.gbxOneTwoThree36.Text = "EX36 One, Two, Three"
        '
        'txtThree36
        '
        Me.txtThree36.Location = New System.Drawing.Point(11, 177)
        Me.txtThree36.Name = "txtThree36"
        Me.txtThree36.Size = New System.Drawing.Size(170, 20)
        Me.txtThree36.TabIndex = 3
        Me.txtThree36.Text = "Three"
        '
        'txtTwo36
        '
        Me.txtTwo36.Location = New System.Drawing.Point(11, 138)
        Me.txtTwo36.Name = "txtTwo36"
        Me.txtTwo36.Size = New System.Drawing.Size(170, 20)
        Me.txtTwo36.TabIndex = 2
        Me.txtTwo36.Text = "Two"
        '
        'brnRight36
        '
        Me.brnRight36.Location = New System.Drawing.Point(214, 150)
        Me.brnRight36.Name = "brnRight36"
        Me.brnRight36.Size = New System.Drawing.Size(75, 23)
        Me.brnRight36.TabIndex = 1
        Me.brnRight36.Text = "Right"
        Me.brnRight36.UseVisualStyleBackColor = True
        '
        'txtOne36
        '
        Me.txtOne36.Location = New System.Drawing.Point(11, 88)
        Me.txtOne36.Name = "txtOne36"
        Me.txtOne36.Size = New System.Drawing.Size(170, 20)
        Me.txtOne36.TabIndex = 4
        Me.txtOne36.Text = "One"
        '
        'btnLeft36
        '
        Me.btnLeft36.Location = New System.Drawing.Point(214, 109)
        Me.btnLeft36.Name = "btnLeft36"
        Me.btnLeft36.Size = New System.Drawing.Size(75, 23)
        Me.btnLeft36.TabIndex = 0
        Me.btnLeft36.Text = "Left"
        Me.btnLeft36.UseVisualStyleBackColor = True
        '
        'frmSulfaroCH23HW
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(716, 499)
        Me.Controls.Add(Me.gbxFace34)
        Me.Controls.Add(Me.gbxColorful35)
        Me.Controls.Add(Me.gbxOneTwoThree36)
        Me.Controls.Add(Me.gbxText33)
        Me.Name = "frmSulfaroCH23HW"
        Me.Text = "Sulfaro CH 2.3 HW"
        Me.gbxText33.ResumeLayout(False)
        Me.gbxText33.PerformLayout()
        Me.gbxFace34.ResumeLayout(False)
        Me.gbxFace34.PerformLayout()
        Me.gbxColorful35.ResumeLayout(False)
        Me.gbxColorful35.PerformLayout()
        Me.gbxOneTwoThree36.ResumeLayout(False)
        Me.gbxOneTwoThree36.PerformLayout()
        Me.ResumeLayout(False)

    End Sub

    Friend WithEvents gbxText33 As GroupBox
    Friend WithEvents txtAllignText33 As TextBox
    Friend WithEvents btnRightJustify33 As Button
    Friend WithEvents btnCenter33 As Button
    Friend WithEvents btnLeftJustify33 As Button
    Friend WithEvents gbxFace34 As GroupBox
    Friend WithEvents gbxColorful35 As GroupBox
    Friend WithEvents gbxOneTwoThree36 As GroupBox
    Friend WithEvents btnFrown34 As Button
    Friend WithEvents btnSmile34 As Button
    Friend WithEvents lblFace34 As Label
    Friend WithEvents lblFore35 As Label
    Friend WithEvents lblBack35 As Label
    Friend WithEvents txtOne36 As TextBox
    Friend WithEvents btnYellow35 As Button
    Friend WithEvents btnBlue35 As Button
    Friend WithEvents btnWhite35 As Button
    Friend WithEvents btnRed35 As Button
    Friend WithEvents txtBox35 As TextBox
    Friend WithEvents txtThree36 As TextBox
    Friend WithEvents txtTwo36 As TextBox
    Friend WithEvents brnRight36 As Button
    Friend WithEvents btnLeft36 As Button
End Class
