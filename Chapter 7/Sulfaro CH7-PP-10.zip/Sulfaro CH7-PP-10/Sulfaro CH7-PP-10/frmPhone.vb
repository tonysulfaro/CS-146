﻿Public Class frmPhone

    ' Program: CH7-PP-10
    ' Name: Anthony Sulfaro
    ' Date: 11/20/16
    ' Class: CS146.04
    ' Program Def:
    ' Displays people and their extensions given user input.

    Structure Employee
        Dim lastName As String
        Dim firstName As String
        Dim extension As String
        Dim Code As String
    End Structure

    Dim people() As Employee

    Dim Code As String = ""

    'Load Time
    Private Sub frmPhone_Load(sender As Object, e As EventArgs) Handles MyBase.Load

        CodeAssign()

    End Sub

    'Handles employee code assingment
    Sub CodeAssign()

        Dim Employee() As String = IO.File.ReadAllLines("EMPLOYEES.txt")
        Dim n As Integer = Employee.Count - 1
        ReDim people(n)
        Dim line As String
        Dim data(2) As String
        For i As Integer = 0 To n
            line = Employee(i)
            data = line.Split(","c)
            people(i).lastName = data(0)
            people(i).firstName = data(1)
            people(i).extension = data(2)
        Next
    End Sub

    'Handles generating code from persons name
    Sub GetPersonCode()

        If Code.StartsWith("5") Then

        End If

    End Sub

    'Output Data to dataGrid
    Sub OutputData()


    End Sub

    'Handles code text changing
    Private Sub mtbCode_TextChanged(sender As Object, e As EventArgs) Handles mtbCode.TextChanged

        Dim query = From employee In people
                    Where employee.extension.StartsWith(Code)
                    Select employee

        OutputData()


    End Sub



    'Add Number onto Code
    Private Sub btn2ABC_Click(sender As Object, e As EventArgs) Handles btn2ABC.Click
        AddButton("2")
        mtbCode.Text = Code
    End Sub

    Private Sub btn3DEF_Click(sender As Object, e As EventArgs) Handles btn3DEF.Click
        AddButton("3")
        mtbCode.Text = Code
    End Sub

    Private Sub btn4GHI_Click(sender As Object, e As EventArgs) Handles btn4GHI.Click
        AddButton("4")
        mtbCode.Text = Code
    End Sub

    Private Sub btn5JKL_Click(sender As Object, e As EventArgs) Handles btn5JKL.Click
        AddButton("5")
        mtbCode.Text = Code
    End Sub

    Private Sub btn6MNO_Click(sender As Object, e As EventArgs) Handles btn6MNO.Click
        AddButton("6")
        mtbCode.Text = Code
    End Sub

    Private Sub btn7PQRS_Click(sender As Object, e As EventArgs) Handles btn7PQRS.Click
        AddButton("7")
        mtbCode.Text = Code
    End Sub

    Private Sub btn8TUV_Click(sender As Object, e As EventArgs) Handles btn8TUV.Click
        AddButton("8")
        mtbCode.Text = Code
    End Sub

    Private Sub btn9WXYZ_Click(sender As Object, e As EventArgs) Handles btn9WXYZ.Click
        AddButton("9")
        mtbCode.Text = Code
    End Sub

    Function AddButton(Num As String)
        If Code.Length <= 3 Then
            Code += Num
        Else
            Code = Code
            MessageBox.Show("The Look up code cannot be longer than 4. Please press " &
                            "'Look Up Another Person' to enter in another code.", "Error")
        End If
        Return Code
    End Function

    'Clear Data grid and text box set Code to null
    Private Sub btnNewPerson_Click(sender As Object, e As EventArgs) Handles btnNewPerson.Click
        mtbCode.Clear()
        dgvDirectory.DataSource = Nothing
        Code = ""
    End Sub

    'User instructions
    Private Sub btnGetInstructions_Click(sender As Object, e As EventArgs) Handles btnGetInstructions.Click
        MessageBox.Show("Enter the first three letters of the person's last name" &
                        " followed by the first letter of the person's first name", "Instructions")
    End Sub

    Private Sub btnExit_Click(sender As Object, e As EventArgs) Handles btnExit.Click
        MessageBox.Show("The program will now close.", "Confirm")
        Me.Close()
    End Sub


End Class
